﻿Public Class url
    Private Sub BunifuThinButton21_Click(sender As Object, e As EventArgs) Handles BunifuThinButton21.Click
        If BunifuMaterialTextbox1.Text = "" Then

        Else
            If ComboBox1.Text = "" Then

            Else
                If ComboBox1.Text = "page 1" Then
                    Dim URL As String = Form1.WebBrowser1.Url.ToString
                    URL = BunifuMaterialTextbox1.Text
                Else

                End If
            End If
        End If

    End Sub

    Private Sub url_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BunifuMaterialTextbox1.HintText = Form1.WebBrowser1.Url.ToString
    End Sub
End Class