﻿Public Class Form1
    Dim etat As Boolean = False
    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        If WebBrowser2.GoBack Then
            WebBrowser2.GoBack()
        End If
    End Sub

    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) Handles ToolStripButton2.Click
        If WebBrowser2.GoForward Then
            WebBrowser2.GoForward()
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ToolStripStatusLabel1.Text = WebBrowser2.StatusText
        ToolStripStatusLabel2.Text = WebBrowser1.StatusText
        ToolStripProgressBar1.Value = WebBrowser2.ReadyState
        ToolStripProgressBar2.Value = WebBrowser1.ReadyState
        If ToolStripProgressBar1.Value = 4 Then
            ToolStripProgressBar1.Value = 0
            StatusStrip1.Visible = False
        End If
        If ToolStripProgressBar2.Value = 4 Then
            ToolStripProgressBar2.Value = 0
            StatusStrip2.Visible = False
        End If

        If ToolStripProgressBar1.Value > 0 Then
            StatusStrip1.Visible = True
        End If
        If ToolStripProgressBar2.Value > 0 Then
            StatusStrip2.Visible = True
        End If




    End Sub

    Private Sub ToolStripButton3_Click(sender As Object, e As EventArgs) Handles ToolStripButton3.Click
        If WebBrowser1.GoBack Then
            WebBrowser1.GoBack()
        End If
    End Sub

    Private Sub ToolStripButton4_Click(sender As Object, e As EventArgs) Handles ToolStripButton4.Click
        If WebBrowser1.GoForward Then
            WebBrowser1.GoForward()
        End If
    End Sub

    Private Sub ToolStripButton5_Click(sender As Object, e As EventArgs) Handles ToolStripButton5.Click
        web_page.Show()

    End Sub
    Sub Address1Stat() Handles WebBrowser2.DocumentCompleted
        ToolStripTextBox1.Text = WebBrowser2.Url.ToString

    End Sub
    Sub Address2Stat() Handles WebBrowser1.DocumentCompleted
        ToolStripTextBox2.Text = WebBrowser1.Url.ToString

    End Sub
    Private Sub ToolStripButton7_Click(sender As Object, e As EventArgs) Handles ToolStripButton7.Click
        WebBrowser2.Navigate(ToolStripTextBox1.Text)
    End Sub

    Private Sub ToolStripButton6_Click(sender As Object, e As EventArgs) Handles ToolStripButton6.Click
        WebBrowser1.Navigate(ToolStripTextBox2.Text)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        WebBrowser1.ScriptErrorsSuppressed = True
        WebBrowser2.ScriptErrorsSuppressed = True
    End Sub

    Private Sub ToolStripButton9_Click(sender As Object, e As EventArgs) Handles ToolStripButton9.Click
        WebBrowser1.Refresh()
    End Sub

    Private Sub ToolStripButton8_Click(sender As Object, e As EventArgs) Handles ToolStripButton8.Click
        WebBrowser2.Refresh()
    End Sub

    Private Sub Address1Stat(sender As Object, e As WebBrowserDocumentCompletedEventArgs) Handles WebBrowser2.DocumentCompleted

    End Sub

    Private Sub ToolStripTextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ToolStripTextBox1.KeyPress
        If e.KeyChar = Chr(Keys.Enter) Then
            WebBrowser2.Navigate(ToolStripTextBox1.Text)
        End If
    End Sub

    Private Sub ToolStripTextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ToolStripTextBox2.KeyPress
        If e.KeyChar = Chr(Keys.Enter) Then
            WebBrowser1.Navigate(ToolStripTextBox2.Text)
        End If
    End Sub

    Private Sub Form1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles MyBase.KeyPress

        If e.KeyChar = Chr(Keys.F11) Then

            If etat = False Then
                Me.FormBorderStyle = FormBorderStyle.None
                ToolStrip1.Visible = False
                Me.WindowState = FormWindowState.Maximized
                Me.TopMost = True
                etat = True
            Else
                Me.FormBorderStyle = FormBorderStyle.Sizable
                ToolStrip1.Visible = True
                Me.WindowState = FormWindowState.Maximized
                Me.TopMost = False
                etat = False
            End If
        End If

    End Sub
End Class
