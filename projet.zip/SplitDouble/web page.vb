﻿Public Class web_page
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        Timer1.Interval = 10
        ToolStripStatusLabel1.Text = WebBrowser1.StatusText
        ToolStripProgressBar1.Value = WebBrowser1.ReadyState
        If ToolStripProgressBar1.Value = 4 Then
            ToolStripProgressBar1.Value = 0
        End If

    End Sub
    Sub AddressStat() Handles WebBrowser1.DocumentCompleted
        ToolStripTextBox1.Text = WebBrowser1.Url.ToString

    End Sub

    Sub DownloadStat() Handles WebBrowser1.FileDownload

    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        If WebBrowser1.GoBack Then
            WebBrowser1.GoBack()
        End If
    End Sub

    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) Handles ToolStripButton2.Click
        If WebBrowser1.GoForward Then
            WebBrowser1.GoForward()
        End If
    End Sub

    Private Sub web_page_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        WebBrowser1.ScriptErrorsSuppressed = True

    End Sub

    Private Sub ToolStripButton4_Click(sender As Object, e As EventArgs) Handles ToolStripButton4.Click
        WebBrowser1.Refresh()
    End Sub

    Private Sub ToolStripButton5_Click(sender As Object, e As EventArgs) Handles ToolStripButton5.Click
        WebBrowser1.Navigate(ToolStripTextBox1.Text)
    End Sub

    Private Sub ToolStripButton6_Click(sender As Object, e As EventArgs) Handles ToolStripButton6.Click
        WebBrowser1.Navigate("https://www.bing.com/search?q=" & ToolStripTextBox2.Text)
    End Sub
End Class